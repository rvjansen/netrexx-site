You are looking at the readme for the NetRexx 3.04RC1 package - NetRexx-3.04RC1.zip

If you are new to NetRexx, please read the contents of the file
read.me.first, and the NetRexx Quick Start Guide (in a pdf in this package).

This is release candidate 1 of NetRexx 3.04
