You are looking at the readme for the NetRexx 3.04 GA package -
NetRexx-3.04GA.zip

If you are new to NetRexx, please read the contents of the file
read.me.first, and the NetRexx Quick Start Guide (in a pdf in this package).

