/* Generated from 'rexxcps.nrx' 12 Jul 2019 15:08:18 [v3.08] */
/* Options: Decimal Format Java Logo Replace Trace2 Verbose3 */


public class rexxcps{
 private static final netrexx.lang.Rexx $01=new netrexx.lang.Rexx("Java method rexxcps.nrx");
 private static final char[] $02={3,1,1,10,1,0,1,10,2,1,2,0};
 private static final netrexx.lang.Rexx $03=new netrexx.lang.Rexx("NetRexx 3.08 25 Mar 2019");
 private static final char[] $04={1,10,1,0,0};
 private static final netrexx.lang.Rexx $05=netrexx.lang.Rexx.toRexx("iterations");
 private static final netrexx.lang.Rexx $06=new netrexx.lang.Rexx((byte)14);
 private static final netrexx.lang.Rexx $07=new netrexx.lang.Rexx(1234);
 private static final netrexx.lang.Rexx $08=netrexx.lang.Rexx.toRexx("5678");
 private static final netrexx.lang.Rexx $09=new netrexx.lang.Rexx("1.1");
 private static final netrexx.lang.Rexx $010=new netrexx.lang.Rexx("2.2");
 private static final netrexx.lang.Rexx $011=new netrexx.lang.Rexx(1);
 private static final netrexx.lang.Rexx $012=new netrexx.lang.Rexx(17);
 private static final netrexx.lang.Rexx $013=netrexx.lang.Rexx.toRexx("foobar");
 private static final netrexx.lang.Rexx $014=new netrexx.lang.Rexx(9);
 private static final netrexx.lang.Rexx $015=new netrexx.lang.Rexx('?');
 private static final netrexx.lang.Rexx $016=new netrexx.lang.Rexx(5);
 private static final netrexx.lang.Rexx $017=new netrexx.lang.Rexx(2);
 private static final netrexx.lang.Rexx $018=new netrexx.lang.Rexx("1.0");
 private static final netrexx.lang.Rexx $019=netrexx.lang.Rexx.toRexx("");
 private static final netrexx.lang.Rexx $020=netrexx.lang.Rexx.toRexx("string");
 private static final netrexx.lang.Rexx $021=new netrexx.lang.Rexx(0);
 private static final netrexx.lang.Rexx $022=new netrexx.lang.Rexx("99.7");
 private static final netrexx.lang.Rexx $023=netrexx.lang.Rexx.toRexx("ring");
 private static final char[] $024={4,1,5,10,1,0,1,10,2,1,2,0};
 private static final netrexx.lang.Rexx $025=netrexx.lang.Rexx.toRexx("with");
 private static final netrexx.lang.Rexx $026=netrexx.lang.Rexx.toRexx("args");
 private static final char[] $027={6,1,10,1,0,1,10,1,2,0};
 private static final netrexx.lang.Rexx $028=new netrexx.lang.Rexx(1000);
 private static final netrexx.lang.Rexx $029=netrexx.lang.Rexx.toRexx("seconds");
 private static final netrexx.lang.Rexx $030=new netrexx.lang.Rexx("0.5");
 private static final char[] $031={1,10,5,0,1,2,3,4,0};
 private static final char[] $032={1,10,4,0,1,2,3,0};
 private static final netrexx.lang.Rexx $033=new netrexx.lang.Rexx((byte)1);
 private static final char[] $034={1,10,3,0,1,2,0};
 private static final java.lang.String $0="rexxcps.nrx";
 
 @SuppressWarnings("unchecked")
 
 public static void main(java.lang.String $0s[]){
  netrexx.lang.Rexx rexxcps;
  netrexx.lang.Rexx count;
  netrexx.lang.Rexx averaging;
  netrexx.lang.Rexx source=null;
  netrexx.lang.Rexx opsystem=null;
  netrexx.lang.Rexx version=null;
  netrexx.lang.Rexx dstats;
  long empty;
  netrexx.lang.Rexx i=null;
  long start=0;
  netrexx.lang.Rexx fempty;
  long full;
  netrexx.lang.Rexx flag=null;
  netrexx.lang.Rexx p0=null;
  netrexx.lang.Rexx lvar=null;
  netrexx.lang.Rexx key1=null;
  netrexx.lang.Rexx acompound=null;
  netrexx.lang.Rexx j=null;
  netrexx.lang.Rexx avar=null;
  netrexx.lang.Rexx v1=null;
  netrexx.lang.Rexx v2=null;
  netrexx.lang.Rexx address=null;
  netrexx.lang.Rexx rc=null;
  netrexx.lang.Rexx p1=null;
  netrexx.lang.Rexx p5=null;
  netrexx.lang.Rexx p2=null;
  netrexx.lang.Rexx p6=null;
  netrexx.lang.Rexx p3=null;
  netrexx.lang.Rexx p7=null;
  netrexx.lang.Rexx p4=null;
  netrexx.lang.Rexx p8=null;
  netrexx.lang.Rexx ffull;
  netrexx.lang.Rexx looptime;
  rexxcps=netrexx.lang.Rexx.toRexx("2.1n");
  count=new netrexx.lang.Rexx((byte)100);
  averaging=new netrexx.lang.Rexx((byte)100);
  {netrexx.lang.Rexx $1[]=new netrexx.lang.Rexx[3];
  netrexx.lang.RexxParse.parse($01,$02,$1);
  source=$1[0];opsystem=$1[1];}
  {netrexx.lang.Rexx $2[]=new netrexx.lang.Rexx[1];
  netrexx.lang.RexxParse.parse($03,$04,$2);
  version=$2[0];}
  dstats=new netrexx.lang.Rexx((byte)1);
  netrexx.lang.RexxIO.Say((netrexx.lang.Rexx.toRexx("----- REXXCPS").OpCcblank(null,rexxcps)).OpCcblank(null,netrexx.lang.Rexx.toRexx("-- Measuring NetRexx clauses/second -----")));
  netrexx.lang.RexxIO.Say(netrexx.lang.Rexx.toRexx(" NetRexx version is:").OpCcblank(null,version));
  netrexx.lang.RexxIO.Say(netrexx.lang.Rexx.toRexx("          System is:").OpCcblank(null,opsystem));
  netrexx.lang.RexxIO.Say((((netrexx.lang.Rexx.toRexx("          Averaging:").OpCcblank(null,averaging)).OpCcblank(null,netrexx.lang.Rexx.toRexx("measures of"))).OpCcblank(null,count)).OpCcblank(null,$05));
  empty=new netrexx.lang.Rexx(0).tolong();
  {netrexx.lang.Rexx $3=averaging;i=new netrexx.lang.Rexx((byte)1);i:for(;i.OpLtEq(null,$3);i=i.OpAdd(null,new netrexx.lang.Rexx(1))){
   start=java.lang.System.currentTimeMillis();
   {int $4=count.OpPlus(null).toint();for(;$4>0;$4--){
    }
   }
   empty=new netrexx.lang.Rexx(empty).OpAdd(null,new netrexx.lang.Rexx(java.lang.System.currentTimeMillis())).OpSub(null,new netrexx.lang.Rexx(start)).tolong();
   }
  }/*i*/
  fempty=new netrexx.lang.Rexx(empty).OpDiv(null,averaging);
  full=new netrexx.lang.Rexx(0).tolong();
  {netrexx.lang.Rexx $5=averaging;i=new netrexx.lang.Rexx((byte)1);i:for(;i.OpLtEq(null,$5);i=i.OpAdd(null,new netrexx.lang.Rexx(1))){
   start=java.lang.System.currentTimeMillis();
   {int $6=count.OpPlus(null).toint();for(;$6>0;$6--){
    flag=new netrexx.lang.Rexx((byte)0);
    p0=new netrexx.lang.Rexx('b');
    {lvar=new netrexx.lang.Rexx((byte)1);lvar:for(;lvar.OpLtEq(null,$06);lvar=lvar.OpAdd(null,new netrexx.lang.Rexx(1))){
     key1=netrexx.lang.Rexx.toRexx("Key Bee");
     acompound=netrexx.lang.Rexx.toRexx("");
     acompound.getnode(key1).leaf.getnode(lvar).leaf=($07.OpCc(null,$08)).substr(new netrexx.lang.Rexx((byte)6),new netrexx.lang.Rexx((byte)2));
     if (flag.OpEq(null,acompound.getnode(key1).leaf.getnode(lvar).leaf)) 
      netrexx.lang.RexxIO.Say("Failed1");
     {netrexx.lang.Rexx $7=$09;j=$09.OpPlus(null);j:for(;j.OpLtEq(null,$010);j=j.OpAdd(null,$7)){
      if (j.OpGt(null,acompound.getnode(key1).leaf.getnode(lvar).leaf)) 
       netrexx.lang.RexxIO.Say("Failed2");
      if ($012.OpLt(null,(key1.length()).OpSub(null,$011))) 
       netrexx.lang.RexxIO.Say("Failed3");
      if (j.OpEq(null,$013)) 
       netrexx.lang.RexxIO.Say("Failed4");
      if ((key1.substr(new netrexx.lang.Rexx((byte)1),new netrexx.lang.Rexx((byte)1))).OpEq(null,$014)) 
       netrexx.lang.RexxIO.Say("Failed5");
      if ((key1.word(new netrexx.lang.Rexx((byte)1))).OpEq(null,$015)) 
       netrexx.lang.RexxIO.Say("Failed6");
      if (j.OpLt(null,$016)) 
       {
        acompound.getnode(key1).leaf.getnode(lvar).leaf=(acompound.getnode(key1).leaf.getnode(lvar).leaf).OpAdd(null,$011);
        if (j.OpEq(null,$017)) 
         break j;
       }
      continue j;
      }
     }/*j*/
     avar=($018.OpCc(null,$019)).OpCc(null,lvar);
     {/*select*/
     if (flag.OpEq(null,$020))
      netrexx.lang.RexxIO.Say("FailedS1");
     else if ((avar.getnode(flag).leaf.getnode(new netrexx.lang.Rexx((byte)2)).leaf).OpEq(null,$021))
      netrexx.lang.RexxIO.Say("FailedS2");
     else if (flag.OpEq(null,$016.OpAdd(null,$022)))
      netrexx.lang.RexxIO.Say("FailedS3");
     else if (flag.toboolean())
      avar.getnode(new netrexx.lang.Rexx((byte)1)).leaf.getnode(new netrexx.lang.Rexx((byte)2)).leaf=(avar.getnode(new netrexx.lang.Rexx((byte)1)).leaf.getnode(new netrexx.lang.Rexx((byte)2)).leaf).OpMult(null,$09);
     else if (flag.OpEqS(null,$021))
      flag=new netrexx.lang.Rexx((byte)0);
     
     else{throw new netrexx.lang.NoOtherwiseException();}
     }
     if (true) 
      flag=new netrexx.lang.Rexx((byte)1);
     {/*select*/
     if (flag.OpEqS(null,$023))
      netrexx.lang.RexxIO.Say("FailedT1");
     else if ((avar.getnode(flag).leaf.getnode(new netrexx.lang.Rexx((byte)3)).leaf).OpEq(null,$021))
      netrexx.lang.RexxIO.Say("FailedT2");
     else if (flag.toboolean())
      avar.getnode(new netrexx.lang.Rexx((byte)1)).leaf.getnode(new netrexx.lang.Rexx((byte)2)).leaf=(avar.getnode(new netrexx.lang.Rexx((byte)1)).leaf.getnode(new netrexx.lang.Rexx((byte)2)).leaf).OpMult(null,$09);
     else if (flag.OpEqS(null,$021))
      flag=new netrexx.lang.Rexx((byte)1);
     
     else{throw new netrexx.lang.NoOtherwiseException();}
     }
     {netrexx.lang.Rexx $8[]=new netrexx.lang.Rexx[3];
     netrexx.lang.RexxParse.parse(netrexx.lang.Rexx.toRexx("Foo Bar"),$024,$8);
     v1=$8[0];v2=$8[1];}
     address=(new netrexx.lang.Rexx(9));
     subroutine(($025.OpCcblank(null,$017)).OpCcblank(null,$026),((netrexx.lang.Rexx.toRexx("(This is the second)").OpCc(null,$011)).OpCc(null,$019)).OpCc(null,$011));
     rc=netrexx.lang.Rexx.toRexx("This is an awfully boring program");
     {netrexx.lang.Rexx $9[]=new netrexx.lang.Rexx[3];
     $9[1]=p0;
     netrexx.lang.RexxParse.parse(rc,$027,$9);
     p1=$9[0];p5=$9[2];}
     rc=netrexx.lang.Rexx.toRexx("is an awfully boring program This");
     {netrexx.lang.Rexx $10[]=new netrexx.lang.Rexx[3];
     $10[1]=p0;
     netrexx.lang.RexxParse.parse(rc,$027,$10);
     p2=$10[0];p6=$10[2];}
     rc=netrexx.lang.Rexx.toRexx("an awfully boring program This is");
     {netrexx.lang.Rexx $11[]=new netrexx.lang.Rexx[3];
     $11[1]=p0;
     netrexx.lang.RexxParse.parse(rc,$027,$11);
     p3=$11[0];p7=$11[2];}
     rc=netrexx.lang.Rexx.toRexx("awfully boring program This is an");
     {netrexx.lang.Rexx $12[]=new netrexx.lang.Rexx[3];
     $12[1]=p0;
     netrexx.lang.RexxParse.parse(rc,$027,$12);
     p4=$12[0];p8=$12[2];}
     }
    }/*lvar*/
    }
   }
   full=new netrexx.lang.Rexx(full).OpAdd(null,new netrexx.lang.Rexx(java.lang.System.currentTimeMillis())).OpSub(null,new netrexx.lang.Rexx(start)).tolong();
   }
  }/*i*/
  ffull=new netrexx.lang.Rexx(full).OpDiv(null,averaging);
  looptime=((ffull.OpSub(null,fempty))).OpDiv(null,(count.OpMult(null,$028)));
  if (dstats.toboolean()) 
   {
    netrexx.lang.RexxIO.Say("");
    netrexx.lang.RexxIO.Say((((((netrexx.lang.Rexx.toRexx("Total (full DO):").OpCcblank(null,((ffull.OpSub(null,fempty))).OpDiv(null,$028))).OpCcblank(null,netrexx.lang.Rexx.toRexx("secs (average of"))).OpCcblank(null,averaging)).OpCcblank(null,netrexx.lang.Rexx.toRexx("measures of"))).OpCcblank(null,count)).OpCcblank(null,netrexx.lang.Rexx.toRexx("iterations)")));
    netrexx.lang.RexxIO.Say((netrexx.lang.Rexx.toRexx("Time for one iteration (1000 clauses) was:").OpCcblank(null,looptime)).OpCcblank(null,$029));
   }
  netrexx.lang.RexxIO.Say("");
  netrexx.lang.RexxIO.Say((netrexx.lang.Rexx.toRexx("     Performance:").OpCcblank(null,(($028.OpDiv(null,looptime).OpAdd(null,$030))).OpDivI(null,$011))).OpCcblank(null,netrexx.lang.Rexx.toRexx("NetRexx clauses per second")));
  netrexx.lang.RexxIO.Say("");
  {System.exit(0);return;}
  }
 
 
 @SuppressWarnings("unchecked")
 
 public static final void subroutine(netrexx.lang.Rexx arg1,netrexx.lang.Rexx arg2){
  netrexx.lang.Rexx a1=null;
  netrexx.lang.Rexx a2=null;
  netrexx.lang.Rexx a3=null;
  netrexx.lang.Rexx a4=null;
  netrexx.lang.Rexx b1=null;
  netrexx.lang.Rexx b2=null;
  netrexx.lang.Rexx b3=null;
  netrexx.lang.Rexx rc=null;
  netrexx.lang.Rexx c1=null;
  netrexx.lang.Rexx c2=null;
  netrexx.lang.Rexx c3=null;
  {netrexx.lang.Rexx $13[]=new netrexx.lang.Rexx[5];
  netrexx.lang.RexxParse.parse(arg1.upper(),$031,$13);
  a1=$13[0];a2=$13[1];a3=$13[2];a4=$13[4];}
  {netrexx.lang.Rexx $14[]=new netrexx.lang.Rexx[4];
  netrexx.lang.RexxParse.parse(a3,$032,$14);
  b1=$14[0];b2=$14[1];b3=$14[2];}
  {int $15=$033.OpPlus(null).toint();for(;$15>0;$15--){
   rc=(a1.OpCcblank(null,a2)).OpCcblank(null,a3);
   {netrexx.lang.Rexx $16[]=new netrexx.lang.Rexx[3];
   netrexx.lang.RexxParse.parse(rc,$034,$16);
   c1=$16[0];c2=$16[1];c3=$16[2];}
   }
  }
  return;
  }
 
 
 private rexxcps(){return;}
 }