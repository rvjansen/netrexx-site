You are looking at the readme for the first release candidate of the NetRexx 3.02 package - NetRexx-3.02RC1.zip

This is not the released 3.02 translator.
