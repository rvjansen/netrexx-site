You are looking at the readme for the NetRexx 3.02 package - NetRexx-3.02GA.zip


Changes since 3.02 RC1 include:

- documentation fixes for the comment formatter and elimination of
  extra spaces in program sources

- a fix for a problem with the Map support, in which a Map as
  constructor argument was chosen in preference to type Rexx; this has
  been corrected

- a fix for the running of the NetRexxF.jar file on some JVM 1.5
  releases. This is now supported again.

- ongoing documentation work, e.g. for the options

- a fix for silently ignored incorrect program options. For these, a
  warning is issued now.

