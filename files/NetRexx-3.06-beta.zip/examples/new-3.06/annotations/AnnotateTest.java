/* Generated from 'AnnotateTest.nrx' 28 Apr 2017 14:19:55 [v3.06] *//* Options: Binary Decimal Java Logo Replace Trace2 Verbose3 */






public class AnnotateTest{private static final java.lang.String $0="AnnotateTest.nrx";

/* properties private unused */
@propz = null
private java.util.ArrayList a=new java.util.ArrayList();
private java.util.TreeMap test=new java.util.TreeMap();


 @SuppressWarnings("unchecked")
public static void main(java.lang.String args[]){
netrexx.lang.RexxIO.Say("hello annotations");return;}



     @Override      @Deprecated /* just to illustrate a comment */ public java.lang.String toString(){
return "Annotations";}


     @Deprecated public void old(){
netrexx.lang.RexxIO.Say("do no use anymore");return;}



     @Author(name = "Jane Doe")      @Author(name = "John Doe") public void repeating(){
netrexx.lang.RexxIO.Say("repeating annotations");return;}


     @Author( name = "Fifi the Cat", date = "2016-01-01" ) public void parameters(){
netrexx.lang.RexxIO.Say("parameters are possible, but all on one line");return;}public AnnotateTest(){return;}}